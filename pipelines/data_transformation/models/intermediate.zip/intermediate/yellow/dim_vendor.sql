{{
  config(
    materialized='table',
    file_format='parquet',
    location_root='s3a://sirius-logs-riwi/tlc/intermediate/yellow/dim_vendor',
    spark_conf={
      'spark.sql.shuffle.partitions': '13',
      'spark.sql.adaptive.enabled': 'true',
      'spark.sql.adaptive.coalescePartitions.enabled': 'true',
      'spark.hadoop.fs.s3a.endpoint': 's3.us-east-2.amazonaws.com',
      'spark.hadoop.fs.s3a.endpoint.region': 'us-east-2',
      'spark.hadoop.fs.s3a.path.style.access': 'true'
    }
  )
}}

WITH dim_vendor AS (
    SELECT *
    FROM (
        VALUES
            (1, 'Creative Mobile Technologies LLC', 'TPEP provider'),
            (2, 'VeriFone Inc.',                    'TPEP provider')
    ) AS t(vendor_id, company_name, description)
)

SELECT * FROM dim_vendor;
