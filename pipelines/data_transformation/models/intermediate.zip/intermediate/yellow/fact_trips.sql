{{
  config(
    materialized='table',
    file_format='parquet',
    location_root='s3a://sirius-logs-riwi/tlc/intermediate/yellow/fact_trips',
    spark_conf={
      'spark.sql.shuffle.partitions': '13',
      'spark.sql.adaptive.enabled': 'true',
      'spark.sql.adaptive.coalescePartitions.enabled': 'true',
      'spark.sql.files.maxPartitionBytes': '67108864',
      'spark.hadoop.fs.s3a.endpoint': 's3.us-east-2.amazonaws.com',
      'spark.hadoop.fs.s3a.endpoint.region': 'us-east-2',
      'spark.hadoop.fs.s3a.path.style.access': 'true'
    }
  )
}}

-- ─────────────────────────────────────────────
-- Tabla de hechos Yellow Taxi
-- Lee TODOS los años y meses desde stg_yellow
-- y genera las FK hacia cada dimensión
-- ─────────────────────────────────────────────

WITH source AS (

    SELECT *
    FROM {{ source('staging', 'stg_yellow') }}

),

fact AS (

    SELECT

        -- ── Claves foráneas calculadas (columnas nuevas) ───────────
        CAST(DATE_FORMAT(DATE(tpep_pickup_datetime), 'yyyyMMdd') AS INTEGER)  AS date_id,

        CAST(
            LPAD(CAST(HOUR(tpep_pickup_datetime)   AS STRING), 2, '0') ||
            LPAD(CAST(MINUTE(tpep_pickup_datetime) AS STRING), 2, '0')
        AS INTEGER)                                                            AS pickup_time_id,

        ROUND(
            (UNIX_TIMESTAMP(tpep_dropoff_datetime) - UNIX_TIMESTAMP(tpep_pickup_datetime)) / 60.0,
        2)                                                                     AS trip_duration_minutes,

        -- ── Todas las columnas originales de stg_yellow ───────────
        vendor_id,
        tpep_pickup_datetime,
        tpep_dropoff_datetime,
        passenger_count,
        trip_distance,
        pu_location_id,
        do_location_id,
        ratecode_id,
        payment_type,
        fare_amount,
        extra,
        tip_amt,
        tolls_amt,
        total_amt,
        true_total_amt,
        comparation_total_amt,
        surcharge,
        mta_tax,
        congestion_surcharge,
        airport_fee,
        cbd_congestion_fee,
        anio,
        mes

    FROM source

)

SELECT * FROM fact;
